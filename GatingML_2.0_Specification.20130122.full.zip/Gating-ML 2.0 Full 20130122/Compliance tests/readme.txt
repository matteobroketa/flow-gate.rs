Gating-ML Compliance Test Suite
*******************************
This test suite is an informative part of Gating-ML 2.0 specification.
Copyright (c) 2012 ISAC (International Society for Advancement of Cytometry).
Free of charge distribution and read-only usage permited. Modification
and all other rights reserved. For all other uses please contact ISAC.

This test suite is intended to determine/verify Gating-ML compliance of third
party analytical software in terms of:

1) Being able to read Gating-ML files
2) Being able to apply gates on list mode data files
3) Being able to perform appropriate data transformations
4) Obtaining correct events membership results for described gates

The test suite contains 2 sets of tests (folders "set 1" and "set 2").
Each set contains an FCS data file, a Gating-ML file and expected results files.

Set 1
*****
There are 50 gates in the gates1.xml Gating-ML file.
These are supposed to be applied on data1.fcs (an FCS2.0 data file).

Set 2
*****
There are 30 gates in the gates2.xml Gating-ML file.
These are supposed to be applied on data2.fcs (an FCS3.0 data file).

Expected results
****************
Each set contains several text-based results files - one for each gate in the test.
The name of the file corresponds to "Results_<GateId>.txt" where <GateId> is the
identifier of the gate. Each of these files contains an ordered sequence of 0/1,
one number per line. This sequence corresponds to the order of events appearing
in the appropriate FCS data file. The number of lines corresponds to the number
of events in the data file. The value zero (0) indicates that the event is not
in the gate, the value one (1) indicates that the event is in the gate.

Summary spreadsheet
*******************
In addition, the Summary.csv file contains an overview of all tests/gates. Each
line describes a gate. Columns provide the following:
- Folder: which folder is the gate in (set 1 or set 2)
- Gating file: the name of the Gating-ML file (gates1.xml or gates2.xml)
- Data file: the name of the FCS data file (data1.fcs or data2.fcs)
- Gate: the identifier of the gate (as used in the Gating-ML file)
- Events in: the number of events expected to be found inside that gate
  when applied on the specified data file.
- Expected result details file: The name of the file with detailed
  expected event memberships as mentioned above
- Gate type: the type of the gate, i.e., RectangleGate, PolygonGate, EllipsoidGate,
  Quadrant, or BooleanGate (And, Or or Not gate).
- Dimensions: the number of dimensions used in the gate (N/A for Boolean gates)
- Scale: Which scaling transformation is used for that gate. The value of FCS
  indicates that only the default channel to scale transformation (as described in
  the FCS data file) should be applied. Values ASinH, Hyperlog, Linear, Logicle and
  Log indicate that the appropriate transformation is used. Ratio means that a new
  dimension created as ration of two FCS dimensions is used. The value Mixed means
  that several different transformation types are being used for different dimensions
  of the gate.
- Compensation: Which compensation is used for the gate. The value None indicated that
  uncompensated values are used. The value FCS indicates that compensation description
  is taken from the FCS data file (i.e., the TEXT segment of the data file). The value
  Gating-ML indicates that compensation defined within the Gating-ML file is used. The
  value "FCS (None)" indicates that the gate calls for compensating according to the
  FCS data file; however, there is no compensation description present in the data file
  and therefore, no compensation shall be applied. Finally, a value Mixed indicates
  that different compensation is used for different dimensions of the gate (e.g.,
  uncompensated for FCS-H and compensated for FL-H).


-------------------------------
Josef Spidlen <jspidlen@bccrc.ca>
December 7, 2012

