Gating-ML 2.0
*************
International Society for Advancement of Cytometry (ISAC)
standard for representing gating descriptions in  flow cytometry

The content of this specification
*********************************
The following is included as part of this specification:

(a) Normative: The text of the Gating-ML 2.0 specification
    providing a detailed description of the Gating-ML 2.0.
    Folder Specification

(b) Normative: The XML schemas Gating-ML.v2.0.xsd,
    Transformations.v2.0.xsd, and DataTypes.v2.0.xsd formally
    defining the syntax of Gating-ML compliant files.
    Folder: XSD

(c) Informative: Examples of Gating-ML  files.
    Folder: Examples

(d) Informative: Gating-ML software compliance tests (a set of
    tests to help developers determine Gating-ML compliance of
    their software tools.
    Folder: Compliance tests

(e) Informative: Java reference implementation of scaling
    transformations used in Gating-ML.
    Folder: Reference Implementation

(f) Informative: HTML documentation of the XML schemas.
    Folder: XSD-doc


